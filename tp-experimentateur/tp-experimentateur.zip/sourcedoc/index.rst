---------------
Experimentateur
---------------


.. toctree::
   :maxdepth: 1

   experience.rst
   marker.rst
   
~~~~~~~~~~
Etat du TP
~~~~~~~~~~

Décrivez ici l'état d'avancement du TP.

~~~~~~~~~~~~~~~~~~~~~~
Réponses aux questions
~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~
stratègie 1
~~~~~~~~~~~


1.2.2

Pour étudier la complexité de cet algorithme , l'opération que nous pouvons compter et le nombre d'utilisation de la fonction compare.

1.2.3

Cet algorithme sors de la boucle de comparaison lorsque le marquer recherché a été trouvé dans la liste positive. Ainsi le pire de cas et celui ou aucun des marqueurs ne se trouve dans la liste positive.

1.2.4

Si on a m la longeur de la liste de marqueur et p la longeur de la liste de positif, alors dans le pire de cas le nombre d'occurence de OP.

 ~~~~~~~~~~~
 stratègie 2
 ~~~~~~~~~~~
 
2.2.2

Ainsi le pire de cas et celui ou aucun des marqueurs ne se trouve dans la liste positive.
min_pos = (len (m))-1 // 2


~~~~~~~~~~~
stratègie 3
~~~~~~~~~~~
3.2.2- Le pire des cas est si tous les marqueurs positifs sont plus grands que les négatifs.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Recherche empirique des cas favorables :
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
1.5.1
op1 = (m-p)*(m-p)
op2 = (m*p)
op3 = m * (p+1)

1.5.2
on peut constater que plus p est proche de m, plus les stratégies sont performantes.





